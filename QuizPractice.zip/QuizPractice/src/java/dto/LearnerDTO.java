package dto;

public record LearnerDTO(int id,
        String fullName,
        String email,
        int gender,
        String phoneNumber,
        String profileImg) {

}
